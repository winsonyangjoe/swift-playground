//: [Previous](@previous)
//: # Protocols
//: ### Defines a blueprint of methods, properties, and other requirements that suit a particular task or piece of functionality
protocol TestProtocol{
    func test()->String
}

class A: TestProtocol{
    func test() -> String {
        return ""
    }
}

//: # Extensions
//: ### Add new functionality to an existing class, structure, enumeration, or protocol type
//extension jeleknya pas compile time

extension A{
    func beta(){
        
    }
}

extension A{
    func baruLagi(){
        
    }
}

let a = A()
a.test()
//: ## Do you have extra will power to click this button? Well, I dare you!
//: [Next](@next)
